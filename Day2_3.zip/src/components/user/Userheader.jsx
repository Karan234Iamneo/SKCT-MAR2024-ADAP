import Logo from "../../assets/images/Karan-Logo.png";
import "../../assets/css/User.css";
import Usernav from "./Usernav";
function Userheader() {
  return (
    <div id="userheader">
      <div id="userheader_left">
        <img src={Logo} alt="Site Logo" id="sitelogo" />
      </div>
      <div id="userheader_right">
        <Usernav />
      </div>
    </div>
  );
}
export default Userheader;
