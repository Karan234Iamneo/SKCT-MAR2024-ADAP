import { Routes, Route, Navigate } from "react-router-dom";
import { useState } from "react";
import Home from "./pages/Home";
import Courses from "./pages/Courses";
import Course from "./pages/Course";
import Contact from "./pages/Contact";
import Profile from "./pages/users/Profile";
import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";
import "./App.css";
import { useEffect } from "react";
function userRoutes() {
  return (
    <Routes>
      <Route path="/profile" element={<Profile />} />
    </Routes>
  );
}
function adminRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Profile />} />
    </Routes>
  );
}
function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  useEffect(() => {
    const token = sessionStorage.getItem("authToken");
    console.log(token);
    if (token) {
      const tokenexpiration = sessionStorage.getItem("tokenexpiration");
      console.log(tokenexpiration);
      if (Date.now() < tokenexpiration) {
        setIsLoggedIn(true);
      }
    }
  });

  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/home" element={<Home />} />
      <Route path="/courses" element={<Courses />} />
      <Route path="/course/:id" element={<Course />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route
        path="/user/*"
        element={isLoggedIn ? userRoutes() : <Navigate to="/login" />}
      />
      <Route
        path="/admin/*"
        element={isLoggedIn ? adminRoutes() : <Navigate to="/login" />}
      />
    </Routes>
  );
}

export default App;
