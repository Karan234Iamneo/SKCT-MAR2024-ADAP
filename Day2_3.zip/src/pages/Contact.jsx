import Userheader from "../components/user/Userheader";

function Contact() {
  return (
    <div>
      <Userheader />
      <h1>Contact</h1>
    </div>
  );
}
export default Contact;
