import { useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../../assets/css/Login.css";
function Register() {
  const navigate = useNavigate();
  const email = useRef();
  const password = useRef();
  const username = useRef();
  const phone = useRef();
  const [loginmsg, setLoginmsg] = useState("");
  function handlesubmit() {
    //check email and password are empty or not
    console.log("clicked");
    if (
      email.current.value === "" ||
      password.current.value === "" ||
      username.current.value === "" ||
      phone.current.value === ""
    ) {
      setLoginmsg("Please fill all the details");
      //set the #login_msg to red color
      document.getElementById("login_msg").style.color = "red";
    } else {
      setLoginmsg("Registered successfully");
      //set the #login_msg to green color
      document.getElementById("login_msg").style.color = "green";
      navigate("/login");
    }
  }
  return (
    <div id="register_container">
      <div id="register_box">
        <h1 id="login_title">Register</h1>
        <p id="login_msg">{loginmsg}</p>
        <form id="login_form">
          <input
            type="text"
            placeholder="Enter your name"
            ref={username}
            id="username"
          />
          <input
            type="email"
            ref={email}
            placeholder="Enter your email"
            id="email"
          />
          <input
            type="number"
            placeholder="Enter your phone"
            ref={phone}
            id="phone"
          />
          <input
            type="password"
            ref={password}
            placeholder="Enter your password"
            id="password"
          />
          <Link to="/register" className="link">
            Login to continue
          </Link>
          <button id="login_btn" type="button" onClick={handlesubmit}>
            Login
          </button>
        </form>
      </div>
    </div>
  );
}

export default Register;
