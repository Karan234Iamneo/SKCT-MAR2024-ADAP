import { useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../../assets/css/Login.css";
function Login() {
  //use navigate hook
  const navigate = useNavigate();
  const email = useRef();
  const password = useRef();
  const [loginmsg, setLoginmsg] = useState("Welcome back");
  function handlesubmit() {
    //check email and password are empty or not
    console.log("clicked");
    if (
      email.current.value === "" ||
      password.current.value === "" ||
      email.current.value === null ||
      password.current.value === null
    ) {
      setLoginmsg("Please enter all the details");
      //set the #login_msg to red color
      document.getElementById("login_msg").style.color = "red";
    } else {
      setLoginmsg("Login successful");
      //set the #login_msg to green color
      document.getElementById("login_msg").style.color = "green";
      sessionStorage.setItem("authToken", "true");
      const token = sessionStorage.getItem("authToken");
      console.log(token);
      //set expiry date for the token from 24 hours from now
      const tokenexpiration = Date.now() + 24 * 60 * 60 * 1000;
      sessionStorage.setItem("tokenexpiration", tokenexpiration);
      const tokenexpiration1 = sessionStorage.getItem("tokenexpiration");
      console.log(tokenexpiration1);
      navigate("/home");
    }
  }
  return (
    <div id="login_container">
      <div id="login_box">
        <h1 id="login_title">Login</h1>
        <p id="login_msg">{loginmsg}</p>
        <form id="login_form">
          <input
            type="email"
            ref={email}
            placeholder="Enter your email"
            id="email"
          />
          <input
            type="password"
            ref={password}
            placeholder="Enter your password"
            id="password"
          />
          <Link to="/register" className="link">
            Register as a new user
          </Link>
          <button id="login_btn" type="button" onClick={handlesubmit}>
            Login
          </button>
        </form>
      </div>
    </div>
  );
}

export default Login;
