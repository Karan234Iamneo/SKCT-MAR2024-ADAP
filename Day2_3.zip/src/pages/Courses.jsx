import { Link } from "react-router-dom";
import Userheader from "../components/user/Userheader";
import { useEffect, useState } from "react";
function Courses() {
  const [courseslist, setCourseslist] = useState([]);
  useEffect(() => {
    let defaultcourses = [
      {
        id: 1,
        name: "Python",
        shortdes:
          "Master Python fundamentals and syntax in this comprehensive course.",
        descript:
          "Master Python fundamentals and syntax in a comprehensive course covering data analysis, machine learning, and web development projects.",
        price: 2000,
        img: "https://cdn.freebiesupply.com/logos/large/2x/python-5-logo-png-transparent.png",
      },
      {
        id: 2,
        name: "Java",
        shortdes:
          "Explore Java's core concepts and object-oriented principles in this engaging course.",
        descript:
          "Explore Java's core concepts and object-oriented principles to build robust applications with hands-on experience in multithreading, networking, and frameworks.",
        price: 2000,
        img: "https://cdn.icon-icons.com/icons2/2415/PNG/512/java_original_wordmark_logo_icon_146459.png",
      },
      {
        id: 3,
        name: "PHP",
        shortdes:
          "Gain a solid understanding of PHP programming and create dynamic web applications.",
        descript:
          "Dive into PHP programming to create dynamic web applications, leveraging powerful features for server-side scripting, database integration, and security practices.",
        price: 2000,
        img: "https://cdn4.iconfinder.com/data/icons/logos-and-brands/512/256_Php_logo-512.png",
      },
      {
        id: 4,
        name: "MySQL",
        shortdes:
          "Immerse yourself in the world of MySQL databases and SQL queries in this comprehensive course.",
        descript:
          "Immerse yourself in MySQL databases and SQL queries, learning to design efficient schemas, optimize performance, and delve into indexing, transactions, and security.",
        price: 2000,
        img: "https://upload.wikimedia.org/wikipedia/labs/8/8e/Mysql_logo.png",
      },
      {
        id: 5,
        name: "Javascript",
        shortdes:
          "Explore the dynamic world of JavaScript and its role in modern web development.",
        descript:
          "Embark on a journey through JavaScript's dynamic world, creating interactive web applications, mastering front-end frameworks, asynchronous programming, and DOM manipulation.",
        price: 2000,
        img: "https://upload.wikimedia.org/wikipedia/commons/6/6a/JavaScript-logo.png",
      },
      {
        id: 6,
        name: "MERN Stack",
        shortdes:
          "Master the MERN (MongoDB, Express, React, Node.js) stack for full-stack web development.",
        descript:
          "Master the MERN (MongoDB, Express, React, Node.js) stack for full-stack web development, building data-driven applications with seamless integration and efficiency.",
        price: 2000,
        img: "https://algoscript.in/assets/img/tools/mern/Mern.png",
      },
    ];
    setCourseslist(defaultcourses);
  });
  return (
    <div>
      <Userheader />
      <div id="courses_grid">
        {courseslist.map((course) => {
          return (
            // eslint-disable-next-line react/jsx-key
            <div id="courses_grid_box">
              <h1>{course.name}</h1>
              <img src={course.img} alt={course.name} />
              <p>{course.shortdes}</p>
              <Link
                className="courses_grid_box_btn"
                to={`/course/${course.id}`}
              >
                View Course
              </Link>
            </div>
          );
        })}
      </div>
    </div>
  );
}
export default Courses;
