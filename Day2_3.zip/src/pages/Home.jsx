import Userheader from "../components/user/Userheader";

function Home() {
  return (
    <div>
      <Userheader />
      <h1>Home</h1>
    </div>
  );
}
export default Home;
