import { Link } from "react-router-dom";
import Userheader from "../components/user/Userheader";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
function Course() {
  const [courseslist, setCourseslist] = useState([]);
  useEffect(() => {
    let defaultcourses = [
      {
        id: 1,
        name: "Python",
        shortdes:
          "Master Python fundamentals and syntax in this comprehensive course.",
        descript:
          "Embark on a transformative journey in mastering Python, the versatile and powerful programming language widely used in data analysis, machine learning, and web development. This comprehensive course covers Python fundamentals and syntax, equipping you with the skills to build real-world projects and applications. Explore the intricacies of Python libraries and frameworks, gaining hands-on experience in creating efficient and scalable solutions. Delve into the realms of data manipulation, visualization, and automation, honing your expertise in Python for diverse industry applications. Elevate your career prospects with in-demand Python programming skills that set you apart in the competitive tech landscape, opening doors to exciting opportunities and challenges. Join us on this Python adventure and unleash your full potential in the dynamic world of programming.",
        price: 2000,
        img: "https://cdn.freebiesupply.com/logos/large/2x/python-5-logo-png-transparent.png",
      },
      {
        id: 2,
        name: "Java",
        shortdes:
          "Explore Java's core concepts and object-oriented principles in this engaging course.",
        descript:
          "Dive into the immersive world of Java programming where you will explore its core concepts and object-oriented principles in-depth, enabling you to build robust and scalable applications. This engaging course offers hands-on experience in Java development, covering essential topics such as multithreading, networking, and Java frameworks. Gain proficiency in writing efficient and reliable Java code, mastering the art of problem-solving and software design. Delve deeper into advanced Java features, including GUI development, database connectivity, and application security, enhancing your skills for real-world projects. Elevate your programming expertise with Java and unlock a myriad of career opportunities in the ever-evolving software development industry. Join us on this Java journey and embark on a path to becoming a proficient Java developer ready to tackle complex challenges and innovate in the digital landscape.",
        price: 2000,
        img: "https://cdn.icon-icons.com/icons2/2415/PNG/512/java_original_wordmark_logo_icon_146459.png",
      },
      {
        id: 3,
        name: "PHP",
        shortdes:
          "Gain a solid understanding of PHP programming and create dynamic web applications.",
        descript:
          "Dive into the dynamic world of PHP programming where you will master its fundamentals and techniques to create dynamic and interactive web applications. This comprehensive course offers a deep dive into server-side scripting with PHP, equipping you with the skills to build robust and scalable web solutions. Discover the power of PHP for database integration, security practices, and popular frameworks, enhancing your proficiency in web development. Gain insights into advanced PHP features such as session management, authentication, and RESTful APIs, enabling you to create modern and efficient web applications. Elevate your skills in PHP programming to pave the way for a successful career in the ever-evolving field of web development. Join us on this PHP journey and unlock the potential to build innovative and impactful web solutions that meet the demands of the digital era.",
        price: 2000,
        img: "https://cdn4.iconfinder.com/data/icons/logos-and-brands/512/256_Php_logo-512.png",
      },
      {
        id: 4,
        name: "MySQL",
        shortdes:
          "Immerse yourself in the world of MySQL databases and SQL queries in this comprehensive course.",
        descript:
          "Immerse yourself in the world of MySQL databases and SQL queries in this comprehensive course where you will gain a solid understanding of database management. Learn to design efficient database schemas, optimize query performance, and explore advanced topics such as indexing, transactions, and database security. Master the art of MySQL administration, acquiring the skills needed to handle data management tasks effectively. Dive deep into the intricacies of database technologies, enabling you to build robust and scalable data solutions for various applications. Elevate your expertise in MySQL and unlock opportunities in backend development and data management roles. Join us on this MySQL journey and pave the way for a successful career in the realm of database technologies.",
        price: 2000,
        img: "https://upload.wikimedia.org/wikipedia/labs/8/8e/Mysql_logo.png",
      },
      {
        id: 5,
        name: "Javascript",
        shortdes:
          "Explore the dynamic world of JavaScript and its role in modern web development.",
        descript:
          "Embark on a journey through the dynamic world of JavaScript, a pivotal language in modern web development, enabling you to create interactive and engaging web applications. This course delves into JavaScript's core concepts, front-end frameworks, asynchronous programming, and DOM manipulation, enhancing your proficiency in web development. Master the art of enhancing user experiences and building responsive web solutions using JavaScript's versatile capabilities. Explore advanced topics such as ES6 features, module bundlers, and client-side routing, empowering you to create cutting-edge web applications. Elevate your skills in JavaScript development and open doors to exciting opportunities in the ever-evolving tech industry. Join us on this JavaScript adventure and unlock the potential to innovate and create impactful web solutions that resonate with users in the digital age.",
        price: 2000,
        img: "https://upload.wikimedia.org/wikipedia/commons/6/6a/JavaScript-logo.png",
      },
      {
        id: 6,
        name: "MERN Stack",
        shortdes:
          "Master the MERN (MongoDB, Express, React, Node.js) stack for full-stack web development.",
        descript:
          "Master the MERN (MongoDB, Express, React, Node.js) stack for full-stack web development, building data-driven applications with seamless integration and efficiency.",
        price: 2000,
        img: "https://algoscript.in/assets/img/tools/mern/Mern.png",
      },
    ];
    setCourseslist(defaultcourses);
  });
  //get the id from params
  const { id } = useParams();
  return (
    <div>
      <Userheader />
      <div id="coursedes">
        {courseslist
          .filter((course) => course.id == id)
          .map((course) => {
            return (
              // eslint-disable-next-line react/jsx-key
              <div id="coursedes_box">
                <h1 id="des_title">{course.name}</h1>
                <p id="des_price">${course.price}</p>
                <p id="des_descript">{course.descript}</p>
                <Link className="enroll_btn" to={`/enroll/${course.id}`}>
                  Enroll
                </Link>
              </div>
            );
          })}
      </div>
    </div>
  );
}
export default Course;
