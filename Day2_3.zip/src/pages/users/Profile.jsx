import Userheader from "../../components/user/Userheader";

function Profile() {
  return (
    <div>
      <Userheader />
      <h1>Profile</h1>
    </div>
  );
}
export default Profile;
